export type Evento = {
  id: number;
  descripcion: string;
  fechaEvento: string;
  rutaId: number;
};
