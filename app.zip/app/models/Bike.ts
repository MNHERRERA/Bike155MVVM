export type Bike = {
  id: number;
  tipo: string;
};
