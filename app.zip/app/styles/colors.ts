export const Colors = {
  primaryBlue: '#002F6C',
  mediumBlue: '#004C99',
  red: '#DA291C',
  yellow: '#FFCC00',
};
